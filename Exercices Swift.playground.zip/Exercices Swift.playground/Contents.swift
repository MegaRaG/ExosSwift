import UIKit

//EXO 1

//1
var tableauAleatoire = [Int]()
for _ in 1...20 {
    tableauAleatoire.append(Int.random(in: 1..<100))
}
//print("tableau : ", tableauAleatoire)
//2
func SommeToutTableau(tableauDeValeurs Valeur: [Int]) -> Int {
    var somme = 0
    for nombre in Valeur{
        somme = somme + nombre
    }
    return somme
}

var resultatSomme = SommeToutTableau(tableauDeValeurs: tableauAleatoire)
//print("Somme : ", resultatSomme)

//3
func MoyenneToutTableau(tableauDeValeurs tableauValeur: [Int]) -> Int {
    var nbValeursDansTableau = tableauValeur.count
    var somme = SommeToutTableau(tableauDeValeurs: tableauAleatoire)
    var moyenne = somme / nbValeursDansTableau
    return moyenne
}

var resultatMoyenne = MoyenneToutTableau(tableauDeValeurs: tableauAleatoire)
//print("Moyenne : ", resultatMoyenne)

//4
//print("Max dans le tableau : " ,tableauAleatoire.max())

//5

func FiltrerPairTableau(tableauDeValeurs Valeur: [Int]) -> [Int] {
    var tableauPair = [Int]()
    for nombre in Valeur{
        if(nombre%2 == 0){
            tableauPair.append(nombre)
        }
    }
    return tableauPair
}
var tableauPair = FiltrerPairTableau(tableauDeValeurs: tableauAleatoire)
//print("Valeurs paires du tableau : ", tableauPair)

//6
func TransformerTabString(tableauDeValeurs tabInt: [Int]) -> [String]{
    var tabString = [String]()
    for nombre in tabInt{
        tabString.append(String(nombre))s
    }
    return tabString
}
var tableauChaine = TransformerTabString(tableauDeValeurs: tableauAleatoire)
//print("Tableau de chaines : ", tableauChaine)

//EXO 2

enum Animal: CaseIterable {
    
    case cat
    case dog
    case elephant
    case giraffe
    case panda
    case penguin
    case cheetah
    case dolphin
    case lion
    case turtle
    
    func AnimalEmoji(animal nomAnimal: Animal){
    val emoji = 🤩
    switch nomAnimal {
    case cat:
        emoji = 😺
    }
        
    }

}

let animal = Animal.cat
